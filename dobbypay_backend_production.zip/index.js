import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool, { initDatabase } from './db.js';
import { registerSaavnRoutes } from './saavnProxy.js';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { sendCustomerApprovalEmail, sendCustomEmail } from './emailService.js';
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Whitelist authorized frontend origins
const defaultOrigins = [
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:5000',
  'http://127.0.0.1:5000',
  'http://localhost',
  'capacitor://localhost',
  'https://localhost'
];

const allowedOrigins = process.env.ALLOWED_ORIGINS 
  ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim()).filter(Boolean)
  : defaultOrigins;

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.indexOf(origin) !== -1 || allowedOrigins.includes('*')) {
      return callback(null, true);
    }
    return callback(new Error(`Origin ${origin} not allowed by CORS`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Bypass-Tunnel-Reminder']
}));

app.use(express.json());

registerSaavnRoutes(app);

// MySQL connection initialization
initDatabase().catch((err) => {
  console.warn('MySQL unavailable (catalog API disabled):', err.message);
});

// ─── GET /api/stats ─────────────────────────────────────────────
app.get('/api/stats', async (req, res) => {
  try {
    const [songRows] = await pool.query('SELECT COUNT(*) as songCount FROM songs');
    const [dirRows] = await pool.query('SELECT COUNT(*) as dirCount FROM directors');
    res.json({
      status: 'active',
      database: process.env.DB_NAME || 'dobbyppay',
      port: process.env.DB_PORT || '3310',
      totalSongs: songRows[0]?.songCount || 0,
      totalDirectors: dirRows[0]?.dirCount || 0
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/songs (Smart Keyword Search & Pagination) ────────
app.get('/api/songs', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;
    const offset = (page - 1) * limit;

    const { language, decade, category, director, search } = req.query;

    let whereConditions = [];
    let queryParams = [];

    if (language && language !== 'all') {
      whereConditions.push('language_id = ?');
      queryParams.push(language.toLowerCase());
    }

    if (decade && decade !== 'all') {
      whereConditions.push('decade = ?');
      queryParams.push(decade);
    }

    if (category && category !== 'all') {
      whereConditions.push('category = ?');
      queryParams.push(category);
    }

    if (director && director.trim()) {
      const cleanDirector = director.trim().replace(/\b(hit|songs|song|music|bgm)\b/gi, '').trim();
      whereConditions.push('director_name LIKE ?');
      queryParams.push(`%${cleanDirector}%`);
    }

    if (search && search.trim()) {
      // Strip common noise words: hit, songs, song, music, bgm
      const cleanSearch = search.trim().replace(/\b(hit|songs|song|music|bgm|theme|collection|full)\b/gi, '').trim();
      const searchTerm = cleanSearch || search.trim();
      
      const words = searchTerm.split(/\s+/).filter(w => w.length > 1);
      if (words.length > 0) {
        const wordConditions = words.map(() => `(title LIKE ? OR artist LIKE ? OR album LIKE ? OR director_name LIKE ?)`).join(' AND ');
        whereConditions.push(`(${wordConditions})`);
        
        words.forEach(w => {
          const pattern = `%${w}%`;
          queryParams.push(pattern, pattern, pattern, pattern);
        });
      }
    }

    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';

    // Total Count Query
    const countSql = `SELECT COUNT(*) as total FROM songs ${whereClause}`;
    const [countResult] = await pool.query(countSql, queryParams);
    const totalSongs = countResult[0]?.total || 0;
    const totalPages = Math.ceil(totalSongs / limit) || 1;

    // Paginated Songs Query
    const songsSql = `
      SELECT 
        id, title, artist, director_name as director, album, 
        duration, duration_sec as durationSec, audio_url as audioUrl, 
        cover_url as coverUrl, genre, release_year as releaseYear, 
        decade, language_id as language, category, plays, color,
        COALESCE(provider, 'local') as provider,
        COALESCE(is_preview, 0) as isPreview,
        COALESCE(playback_type, 'full') as playbackType,
        COALESCE(license_note, 'Authorized Stream') as licenseNote,
        source_id as sourceId
      FROM songs 
      ${whereClause} 
      ORDER BY release_year DESC, id ASC 
      LIMIT ? OFFSET ?
    `;

    const [songs] = await pool.query(songsSql, [...queryParams, limit, offset]);

    res.json({
      success: true,
      songs,
      pagination: {
        currentPage: page,
        totalPages,
        totalSongs,
        limit,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      }
    });
  } catch (err) {
    console.error('API /api/songs error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── GET /api/songs/:id (Fetch Single Song with Full Audio Stream) ──
app.get('/api/songs/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query(`
      SELECT 
        id, title, artist, director_name as director, album, 
        duration, duration_sec as durationSec, audio_url as audioUrl, 
        cover_url as coverUrl, genre, release_year as releaseYear, 
        decade, language_id as language, category, plays, color,
        COALESCE(provider, 'local') as provider,
        COALESCE(is_preview, 0) as isPreview,
        COALESCE(playback_type, 'full') as playbackType,
        COALESCE(license_note, 'Authorized Stream') as licenseNote,
        source_id as sourceId
      FROM songs 
      WHERE id = ? OR title = ?
      LIMIT 1
    `, [id, id]);

    if (rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Song not found in MySQL database' });
    }

    res.json({ success: true, song: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── GET /api/directors ──────────────────────────────────────────
app.get('/api/directors', async (req, res) => {
  try {
    const { language } = req.query;
    let sql = `SELECT id, name, language_id as language, tagline, cover_url as coverUrl, color, bio FROM directors`;
    let params = [];

    if (language && language !== 'all') {
      sql += ` WHERE language_id = ?`;
      params.push(language.toLowerCase());
    }

    const [directors] = await pool.query(sql, params);
    res.json({ success: true, directors });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/songs (Upsert Full Song to MySQL) ────────────────
app.post('/api/songs', async (req, res) => {
  try {
    const {
      id, title, artist, director, album, duration, durationSec,
      audioUrl, coverUrl, genre, releaseYear, decade, language, category,
      provider, isPreview, playbackType, licenseNote, sourceId
    } = req.body;

    if (!title || !audioUrl) {
      return res.status(400).json({ success: false, error: 'Title and audioUrl are required' });
    }

    const songId = id || `song-${Date.now()}`;
    const year = parseInt(releaseYear) || 2024;
    const durSec = parseInt(durationSec) || 240;
    const isPrev = isPreview ? 1 : 0;
    const prov = provider || 'local';
    const pbType = playbackType || (isPrev ? 'preview' : 'full');
    const licNote = licenseNote || (isPrev ? '30s Preview' : 'Authorized Full Track');

    await pool.query(
      `INSERT INTO songs 
       (id, title, artist, director_name, album, duration, duration_sec, audio_url, cover_url, genre, release_year, decade, language_id, category, provider, is_preview, playback_type, license_note, source_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
       title=?, artist=?, director_name=?, album=?, duration=?, duration_sec=?, audio_url=?, cover_url=?, genre=?, release_year=?, decade=?, language_id=?, category=?, provider=?, is_preview=?, playback_type=?, license_note=?, source_id=?`,
      [
        songId, title, artist || 'Unknown', director || 'Unknown', album || 'Single',
        duration || '4:00', durSec, audioUrl, coverUrl || '', genre || 'Indian Hit',
        year, decade || '2020s', (language || 'tamil').toLowerCase(), category || 'songs',
        prov, isPrev, pbType, licNote, sourceId || null,
        title, artist || 'Unknown', director || 'Unknown', album || 'Single',
        duration || '4:00', durSec, audioUrl, coverUrl || '', genre || 'Indian Hit',
        year, decade || '2020s', (language || 'tamil').toLowerCase(), category || 'songs',
        prov, isPrev, pbType, licNote, sourceId || null
      ]
    );

    res.json({ success: true, message: 'Song upserted successfully in MySQL database!', songId });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── DobbyPay Authentication & MySQL `users` Table Management ─────────
// Supports PHP bcrypt ($2y$/$2a$) and SHA-256 password hashing
const hashPasswordBcrypt = (pwd) => bcrypt.hashSync(String(pwd), 10);

function verifyPassword(pwd, hash) {
  if (!hash) return false;
  const strPwd = String(pwd);
  const strHash = String(hash);
  try {
    if (bcrypt.compareSync(strPwd, strHash)) return true;
  } catch (_) {}
  try {
    const hash2a = strHash.replace(/^\$2y\$/, '$2a$');
    if (bcrypt.compareSync(strPwd, hash2a)) return true;
  } catch (_) {}
  const sha = crypto.createHash('sha256').update(strPwd).digest('hex');
  if (strHash === sha || strHash === strPwd) return true;
  return false;
}


// ─── DobbyPay Authentication & MySQL `users` Handlers ──────────────────

// Shared Registration Logic
async function handleRegister(req, res) {
  try {
    const { username, email, password, full_name, name: rawName, phone } = req.body || {};
    const displayName = full_name || username || rawName;
    if (!displayName || !email || !password) {
      return res.status(400).json({ success: false, status: false, error: 'Name, email, and password are required' });
    }

    const name = String(displayName).trim();
    const cleanEmail = String(email).trim().toLowerCase();
    const cleanPassHash = hashPasswordBcrypt(password);
    const cleanPhone = phone ? String(phone).trim() : null;

    // Check if user already exists in `users`
    const [existing] = await pool.query(
      'SELECT id, email, name FROM users WHERE LOWER(email) = ? OR LOWER(name) = ? LIMIT 1',
      [cleanEmail, name.toLowerCase()]
    );

    if (existing && existing.length > 0) {
      return res.status(409).json({ success: false, status: false, error: 'Email or name is already registered in DobbyPay' });
    }

    // Insert into `users` table as pending approval
    const [result] = await pool.query(
      `INSERT INTO users (
        name,
        email,
        password_hash,
        role,
        avatar,
        phone,
        status,
        email_verified,
        admin_approved,
        superadmin_approved
      ) VALUES (?, ?, ?, 'client', NULL, ?, 'pending', 1, 0, 0)`,
      [name, cleanEmail, cleanPassHash, cleanPhone]
    );

    const userId = result.insertId;
    const upiId = `${name.toLowerCase().replace(/[^a-z0-9]/g, '')}${userId}@dobbypay`;
    const accNumber = 'DP' + Math.floor(100000 + Math.random() * 900000);

    // Create DobbyPay UPI wallet account with $100.00 welcome bonus
    try {
      await pool.query(
        `INSERT INTO upi_accounts (
          user_id,
          bank_name,
          account_number,
          ifsc_code,
          account_holder,
          upi_id,
          upi_pin_hash,
          balance,
          is_primary
        ) VALUES (?, 'DobbyPay Digital Bank', ?, 'DOBBY001', ?, ?, '', 100.00, 1)`,
        [userId, accNumber, name, upiId]
      );

      // Record welcome bonus in upi_transactions
      const txnRef = 'TXN' + Date.now();
      await pool.query(
        `INSERT INTO upi_transactions (
          sender_upi_id,
          receiver_upi_id,
          sender_name,
          receiver_name,
          amount,
          txn_ref,
          status,
          note
        ) VALUES ('rewards@dobbypay', ?, 'DobbyPay Rewards', ?, 100.00, ?, 'SUCCESS', 'Spotify Clone Welcome Bonus')`,
        [upiId, name, txnRef]
      );
    } catch (upiErr) {
      console.warn('UPI wallet auto-init note:', upiErr.message);
    }

    const user = {
      id: userId,
      name,
      username: name,
      email: cleanEmail,
      role: 'client',
      phone: cleanPhone,
      status: 'pending',
      admin_approved: 0,
      superadmin_approved: 0,
      wallet_balance: 100.00,
      upi_id: upiId,
      reward_points: 500,
      vip_status: false
    };

    return res.status(201).json({
      success: true,
      status: true,
      pendingApproval: true,
      message: 'Registration successful! Your account is pending Admin & Super Admin approval before you can log in.',
      user
    });
  } catch (err) {
    console.error('Registration error:', err);
    return res.status(500).json({ success: false, status: false, error: err.message });
  }
}

// Shared Login Logic
async function handleLogin(req, res) {
  try {
    const { identifier, email, username, password } = req.body || {};
    const loginIdent = identifier || email || username;
    if (!loginIdent || !password) {
      return res.status(400).json({ success: false, status: false, error: 'Email/username and password are required' });
    }

    const cleanIdent = String(loginIdent).trim().toLowerCase();

    // Query `users` table
    const [rows] = await pool.query(
      `SELECT id, name, email, password_hash, role, avatar, phone, status, email_verified, admin_approved, superadmin_approved
       FROM users
       WHERE LOWER(email) = ? OR LOWER(name) = ? LIMIT 1`,
      [cleanIdent, cleanIdent]
    );

    if (!rows || rows.length === 0) {
      return res.status(401).json({ success: false, status: false, error: 'Invalid username/email or password' });
    }

    const userRow = rows[0];
    if (!verifyPassword(password, userRow.password_hash)) {
      return res.status(401).json({ success: false, status: false, error: 'Invalid username/email or password' });
    }

    const role = String(userRow.role || 'client').toLowerCase();
    const isAdminOrSuper = (role === 'admin' || role === 'super_admin');
    const isApproved = (Number(userRow.admin_approved) === 1 && Number(userRow.superadmin_approved) === 1 && userRow.status === 'active');

    if (!isAdminOrSuper && !isApproved) {
      return res.status(403).json({
        success: false,
        status: false,
        notApproved: true,
        error: 'Account Pending Admin / Super Admin Approval. Your account must be approved before you can access DobbyPay Music.',
        user: {
          id: userRow.id,
          name: userRow.name,
          username: userRow.name,
          email: userRow.email,
          role: userRow.role,
          status: userRow.status || 'pending',
          admin_approved: userRow.admin_approved,
          superadmin_approved: userRow.superadmin_approved,
          phone: userRow.phone
        },
        adminWhatsApp: process.env.ADMIN_WHATSAPP || '+918270006116'
      });
    }

    // Retrieve UPI account and wallet balance
    let walletBalance = 100.00;
    let upiId = `${userRow.name.toLowerCase().replace(/[^a-z0-9]/g, '')}@dobbypay`;

    try {
      const [upiRows] = await pool.query(
        `SELECT id, balance, upi_id FROM upi_accounts WHERE user_id = ? ORDER BY is_primary DESC, id ASC LIMIT 1`,
        [userRow.id]
      );

      if (upiRows && upiRows.length > 0) {
        walletBalance = parseFloat(upiRows[0].balance) || 0;
        if (upiRows[0].upi_id) upiId = upiRows[0].upi_id;
      } else {
        const accNumber = 'DP' + Math.floor(100000 + Math.random() * 900000);
        await pool.query(
          `INSERT INTO upi_accounts (user_id, bank_name, account_number, ifsc_code, account_holder, upi_id, upi_pin_hash, balance, is_primary)
           VALUES (?, 'DobbyPay Digital Bank', ?, 'DOBBY001', ?, ?, '', 100.00, 1)`,
          [userRow.id, accNumber, userRow.name, upiId]
        );
      }
    } catch (_) {}

    // Retrieve recent transactions
    let transactions = [];
    try {
      const [txRows] = await pool.query(
        `SELECT id, sender_upi_id, receiver_upi_id, sender_name, receiver_name, amount, txn_ref, status, note, created_at
         FROM upi_transactions
         WHERE receiver_upi_id = ? OR sender_upi_id = ?
         ORDER BY id DESC LIMIT 20`,
        [upiId, upiId]
      );
      transactions = txRows || [];
    } catch (_) {}

    const user = {
      id: userRow.id,
      name: userRow.name,
      username: userRow.name,
      email: userRow.email,
      role: userRow.role,
      avatar_url: userRow.avatar,
      phone: userRow.phone,
      status: userRow.status,
      wallet_balance: walletBalance,
      upi_id: upiId,
      reward_points: 500,
      vip_status: userRow.role === 'admin' || userRow.role === 'super_admin' || userRow.status === 'active'
    };

    return res.status(200).json({
      success: true,
      status: true,
      message: `Welcome back, ${user.name}!`,
      user,
      transactions
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, status: false, error: err.message });
  }
}

// Register endpoints
app.post('/api/auth/register', handleRegister);
app.post('/api/register', handleRegister);

// Login endpoints
app.post('/api/auth/login', handleLogin);
app.post('/api/login', handleLogin);

// Legacy PHP Endpoint Compatibility Router
app.all(['/backend/api/api.php', '/api.php', '/backend/api'], async (req, res) => {
  const action = req.query.action || req.body?.action;
  if (action === 'register') {
    return handleRegister(req, res);
  }
  if (action === 'login') {
    return handleLogin(req, res);
  }
  if (action === 'songs') {
    try {
      const [rows] = await pool.query('SELECT * FROM songs LIMIT 100');
      return res.json({ success: true, status: true, songs: rows || [] });
    } catch (err) {
      return res.status(500).json({ success: false, status: false, error: err.message });
    }
  }
  if (action === 'directors') {
    try {
      const [rows] = await pool.query('SELECT * FROM directors');
      return res.json({ success: true, status: true, directors: rows || [] });
    } catch (err) {
      return res.status(500).json({ success: false, status: false, error: err.message });
    }
  }
  if (action === 'admin_users') {
    try {
      const [rows] = await pool.query('SELECT id, name, email, role, phone, status, admin_approved, superadmin_approved, created_at FROM users ORDER BY id DESC');
      return res.json({ success: true, status: true, users: rows || [] });
    } catch (err) {
      return res.status(500).json({ success: false, status: false, error: err.message });
    }
  }

  // API Health Check
  res.json({
    status: true,
    success: true,
    message: 'DobbyPay Music API is online and fully functional!',
    server: req.headers.host || 'localhost:5000',
    endpoints: {
      login: 'POST ?action=login or /api/auth/login',
      register: 'POST ?action=register or /api/auth/register',
      songs: 'GET ?action=songs or /api/songs',
      directors: 'GET ?action=directors or /api/directors',
      admin_users: 'GET ?action=admin_users or /api/admin/users'
    }
  });
});

// POST /api/wallet/tip
app.post('/api/wallet/tip', async (req, res) => {
  try {
    const { userId, amount, artist, trackTitle, note } = req.body;
    const tipAmt = parseFloat(amount);
    if (!tipAmt || tipAmt <= 0) {
      return res.status(400).json({ success: false, error: 'Valid tip amount required' });
    }

    const uid = userId || 1;
    let newBal = 0;
    let upiId = 'user@dobbypay';

    try {
      const [upiRows] = await pool.query(
        'SELECT id, balance, upi_id, account_holder FROM upi_accounts WHERE user_id = ? ORDER BY is_primary DESC LIMIT 1',
        [uid]
      );

      if (upiRows && upiRows.length > 0) {
        const curBal = parseFloat(upiRows[0].balance) || 0;
        if (curBal < tipAmt) {
          return res.status(400).json({ success: false, error: 'Insufficient DobbyPay wallet balance' });
        }
        newBal = curBal - tipAmt;
        upiId = upiRows[0].upi_id;

        await pool.query('UPDATE upi_accounts SET balance = ? WHERE id = ?', [newBal, upiRows[0].id]);

        const txnRef = 'TIP' + Date.now();
        await pool.query(
          `INSERT INTO upi_transactions (sender_upi_id, receiver_upi_id, sender_name, receiver_name, amount, txn_ref, status, note)
           VALUES (?, 'artist@dobbypay', ?, ?, ?, ?, 'SUCCESS', ?)`,
          [upiId, upiRows[0].account_holder, artist || 'Artist', tipAmt, txnRef, note || `Tip for ${trackTitle}`]
        );
      }
    } catch (err) {
      console.warn('Tip transaction query note:', err.message);
    }

    res.json({
      success: true,
      message: `Tipped $${tipAmt.toFixed(2)} to ${artist}!`,
      balance: newBal,
      points: Math.round(tipAmt * 10)
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/wallet/topup
app.post('/api/wallet/topup', async (req, res) => {
  try {
    const { userId, amount } = req.body;
    const addAmt = parseFloat(amount);
    if (!addAmt || addAmt <= 0) {
      return res.status(400).json({ success: false, error: 'Valid top-up amount required' });
    }

    const uid = userId || 1;
    let newBal = addAmt;

    try {
      const [upiRows] = await pool.query(
        'SELECT id, balance, upi_id, account_holder FROM upi_accounts WHERE user_id = ? ORDER BY is_primary DESC LIMIT 1',
        [uid]
      );

      if (upiRows && upiRows.length > 0) {
        newBal = (parseFloat(upiRows[0].balance) || 0) + addAmt;
        await pool.query('UPDATE upi_accounts SET balance = ? WHERE id = ?', [newBal, upiRows[0].id]);

        const txnRef = 'TOP' + Date.now();
        await pool.query(
          `INSERT INTO upi_transactions (sender_upi_id, receiver_upi_id, sender_name, receiver_name, amount, txn_ref, status, note)
           VALUES ('bank@dobbypay', ?, 'DobbyPay Bank', ?, ?, ?, 'SUCCESS', 'Wallet Top-Up')`,
          [upiRows[0].upi_id, upiRows[0].account_holder, addAmt, txnRef]
        );
      }
    } catch (err) {
      console.warn('Topup query note:', err.message);
    }

    res.json({
      success: true,
      message: `Added $${addAmt.toFixed(2)} to DobbyPay Wallet!`,
      balance: newBal
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/wallet/transactions
app.get('/api/wallet/transactions', async (req, res) => {
  try {
    const userId = req.query.userId || 1;
    const [upiRows] = await pool.query(
      'SELECT upi_id FROM upi_accounts WHERE user_id = ? ORDER BY is_primary DESC LIMIT 1',
      [userId]
    );

    const upiId = upiRows && upiRows[0] ? upiRows[0].upi_id : '';
    const [rows] = await pool.query(
      `SELECT id, sender_upi_id, receiver_upi_id, sender_name, receiver_name, amount, txn_ref, status, note, created_at
       FROM upi_transactions
       WHERE receiver_upi_id = ? OR sender_upi_id = ?
       ORDER BY id DESC LIMIT 50`,
      [upiId, upiId]
    );

    res.json({ success: true, transactions: rows || [] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Super Admin User Management & Email Notification Endpoints ───────

// GET /api/admin/users — Returns all users from MySQL with approval status
app.get('/api/admin/users', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT id, name, email, role, phone, status, email_verified, admin_approved, superadmin_approved, created_at
       FROM users
       ORDER BY id DESC`
    );
    res.json({ success: true, users: rows || [] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/approve-user — Multi-stage approval (Admin & Super Admin) & HTML email dispatch
app.post('/api/admin/approve-user', async (req, res) => {
  try {
    const { userId, approvedBy = 'Admin', action = 'super_approve' } = req.body;
    if (!userId) {
      return res.status(400).json({ success: false, error: 'User ID is required' });
    }

    // 1. Fetch user from database
    const [userRows] = await pool.query(
      'SELECT id, name, email, role, status, admin_approved, superadmin_approved FROM users WHERE id = ? LIMIT 1',
      [userId]
    );

    if (!userRows || userRows.length === 0) {
      return res.status(404).json({ success: false, error: 'User not found in database' });
    }

    const targetUser = userRows[0];
    let updateSql = '';
    let emailStage = 'super_approve';
    let defaultMsg = '';

    if (action === 'admin_approve') {
      updateSql = `UPDATE users SET admin_approved = 1 WHERE id = ?`;
      emailStage = 'admin_approve';
      defaultMsg = `User approved by Admin! Awaiting Super Admin activation. Email sent to ${targetUser.email}`;
    } else if (action === 'super_approve' || action === 'super_fast_approve') {
      updateSql = `UPDATE users SET admin_approved = 1, superadmin_approved = 1, status = 'active' WHERE id = ?`;
      emailStage = 'super_approve';
      defaultMsg = `User fully activated by Super Admin! Confirmation email sent to ${targetUser.email}`;
    } else if (action === 'admin_reject' || action === 'super_reject') {
      const col = action === 'admin_reject' ? 'admin_approved' : 'superadmin_approved';
      updateSql = `UPDATE users SET ${col} = -1, status = 'suspended' WHERE id = ?`;
      emailStage = action;
      defaultMsg = `User registration rejected. Status email sent to ${targetUser.email}`;
    } else if (action === 'reactivate') {
      updateSql = `UPDATE users SET admin_approved = 1, superadmin_approved = 1, status = 'active' WHERE id = ?`;
      emailStage = 'super_approve';
      defaultMsg = `User account reactivated. Notification email sent to ${targetUser.email}`;
    } else {
      updateSql = `UPDATE users SET admin_approved = 1, superadmin_approved = 1, status = 'active' WHERE id = ?`;
      emailStage = 'super_approve';
      defaultMsg = `User approved and activated.`;
    }

    // 2. Update user status in MySQL
    await pool.query(updateSql, [userId]);
    console.log(`✅ [${action}] User in MySQL: ${targetUser.email} (ID: ${userId}) by ${approvedBy}`);

    // 3. Send approval notification email to customer
    const emailResult = await sendCustomerApprovalEmail({
      toEmail: targetUser.email,
      customerName: targetUser.name,
      role: targetUser.role || 'client',
      approvedBy,
      stage: emailStage
    });

    res.json({
      success: true,
      message: defaultMsg,
      emailStatus: emailResult,
      action
    });
  } catch (err) {
    console.error('Approve user error:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 DobbyPay Music MySQL REST API Server running at http://localhost:${PORT}`);
});


