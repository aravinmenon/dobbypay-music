import dotenv from 'dotenv';
dotenv.config();

let pool = null;
let isMySQLAvailable = false;
const inMemorySongs = [];
const inMemoryDirectors = [];

let mysqlModule = null;
try {
  mysqlModule = await import('mysql2/promise');
} catch (err) {
  console.log('ℹ️ MySQL driver optional - Standalone Phone Storage Mode active.');
}

async function createPoolWithConfig(config) {
  if (!mysqlModule) return null;
  const isSslRequired = config.ssl || process.env.DB_SSL === 'true' || (config.host && config.host.includes('aivencloud.com'));
  const poolOpts = {
    host: config.host || process.env.DB_HOST || '127.0.0.1',
    port: parseInt(config.port || process.env.DB_PORT || '3310'),
    user: config.user || process.env.DB_USER || 'root',
    password: config.password !== undefined ? config.password : (process.env.DB_PASS || ''),
    database: config.database || process.env.DB_NAME || 'dobbyppay',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    connectTimeout: 5000
  };
  if (isSslRequired) {
    poolOpts.ssl = { rejectUnauthorized: false };
  }
  return mysqlModule.default.createPool(poolOpts);
}

// Try initial pool from environment variables (Aiven Cloud MySQL)
if (mysqlModule) {
  pool = await createPoolWithConfig({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    ssl: process.env.DB_SSL === 'true'
  });
}

export async function initDatabase() {
  if (!mysqlModule) {
    console.log('📱 Phone Storage Mode: MySQL disabled. App runs 100% on device/local storage.');
    return;
  }
  let conn = null;
  try {
    if (pool) {
      conn = await pool.getConnection();
      isMySQLAvailable = true;
    }
  } catch (err) {
    console.warn(`Primary DB connection failed (${process.env.DB_HOST}:${process.env.DB_PORT}): ${err.message}. Trying local MySQL fallback...`);
    // Try local MySQL fallbacks (Port 3310 and 3306)
    const localConfigs = [
      { host: '127.0.0.1', port: 3310, user: 'root', password: '', database: 'dobbyppay' },
      { host: '127.0.0.1', port: 3306, user: 'root', password: '', database: 'dobbyppay' },
      { host: 'localhost', port: 3310, user: 'root', password: '', database: 'dobbyppay' }
    ];
    for (const cfg of localConfigs) {
      try {
        const fallbackPool = await createPoolWithConfig(cfg);
        conn = await fallbackPool.getConnection();
        pool = fallbackPool;
        isMySQLAvailable = true;
        console.log(`✅ Connected to local MySQL fallback at ${cfg.host}:${cfg.port} (${cfg.database})`);
        break;
      } catch (_) {}
    }
  }

  if (!conn) {
    isMySQLAvailable = false;
    console.log('📱 No MySQL server available. Running in Safe Phone Storage Mode.');
    return;
  }

  try {
    await conn.query(`
      CREATE TABLE IF NOT EXISTS languages (
        id VARCHAR(32) PRIMARY KEY,
        name VARCHAR(64) NOT NULL,
        icon VARCHAR(16),
        color VARCHAR(16)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS directors (
        id VARCHAR(64) PRIMARY KEY,
        name VARCHAR(128) NOT NULL,
        language_id VARCHAR(32),
        tagline VARCHAR(255),
        cover_url TEXT,
        color VARCHAR(16),
        bio TEXT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS songs (
        id VARCHAR(64) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        artist VARCHAR(255) NOT NULL,
        director_name VARCHAR(128),
        album VARCHAR(255),
        duration VARCHAR(16) DEFAULT '4:00',
        duration_sec INT NOT NULL DEFAULT 240,
        audio_url TEXT NOT NULL,
        cover_url TEXT,
        genre VARCHAR(64),
        release_year INT NOT NULL DEFAULT 2024,
        decade VARCHAR(16) NOT NULL DEFAULT '2020s',
        language_id VARCHAR(32) NOT NULL DEFAULT 'tamil',
        category VARCHAR(32) DEFAULT 'songs',
        plays VARCHAR(32) DEFAULT '100,000',
        color VARCHAR(16) DEFAULT '#FF6B00',
        provider VARCHAR(64) DEFAULT 'local',
        is_preview TINYINT(1) DEFAULT 0,
        playback_type VARCHAR(32) DEFAULT 'full',
        license_note VARCHAR(255) DEFAULT 'Authorized Stream',
        source_id VARCHAR(128) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    try { await conn.query(`ALTER TABLE songs ADD COLUMN provider VARCHAR(64) DEFAULT 'local'`); } catch (_) {}
    try { await conn.query(`ALTER TABLE songs ADD COLUMN is_preview TINYINT(1) DEFAULT 0`); } catch (_) {}
    try { await conn.query(`ALTER TABLE songs ADD COLUMN playback_type VARCHAR(32) DEFAULT 'full'`); } catch (_) {}
    try { await conn.query(`ALTER TABLE songs ADD COLUMN license_note VARCHAR(255) DEFAULT 'Authorized Stream'`); } catch (_) {}
    try { await conn.query(`ALTER TABLE songs ADD COLUMN source_id VARCHAR(128) DEFAULT NULL`); } catch (_) {}

    await conn.query(`
      CREATE TABLE IF NOT EXISTS dobbypay_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(64) NOT NULL UNIQUE,
        email VARCHAR(128) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(128) DEFAULT '',
        wallet_balance DECIMAL(10,2) NOT NULL DEFAULT 100.00,
        reward_points INT NOT NULL DEFAULT 500,
        vip_status TINYINT(1) NOT NULL DEFAULT 0,
        avatar_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS dobbypay_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        type VARCHAR(32) NOT NULL,
        artist VARCHAR(128),
        track_title VARCHAR(255),
        amount DECIMAL(10,2) NOT NULL,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    console.log('⚡ MySQL Database connected successfully with DobbyPay user tables.');
  } catch (err) {
    isMySQLAvailable = false;
    console.log('📱 No MySQL server needed. Running in 100% On-Device / Phone Storage Mode.');
  } finally {
    if (conn) conn.release();
  }
}

// Fallback proxy that safely handles queries when MySQL is absent
const safePool = {
  async query(sql, params = []) {
    if (isMySQLAvailable && pool) {
      try {
        return await pool.query(sql, params);
      } catch (err) {
        console.warn('MySQL query error, using local fallback:', err.message);
      }
    }
    // Safe in-memory responses when MySQL is not running
    const sqlUpper = String(sql).toUpperCase();
    if (sqlUpper.includes('COUNT(*)')) {
      return [[{ total: inMemorySongs.length, songCount: inMemorySongs.length, dirCount: inMemoryDirectors.length }]];
    }
    if (sqlUpper.includes('SELECT') && sqlUpper.includes('DIRECTORS')) {
      return [inMemoryDirectors];
    }
    if (sqlUpper.includes('INSERT INTO SONGS')) {
      if (params && params[0]) {
        inMemorySongs.push({ id: params[0], title: params[1], artist: params[2], audio_url: params[7] });
      }
      return [{ affectedRows: 1 }];
    }
    return [inMemorySongs];
  },
  async getConnection() {
    if (isMySQLAvailable && pool) {
      return await pool.getConnection();
    }
    return {
      query: (...args) => safePool.query(...args),
      release: () => {}
    };
  }
};

export default safePool;

